import React from 'react';
import { User, MapPin, Calendar, Award, MessageCircle, Heart } from 'lucide-react';

export const Profile: React.FC = () => {
  const user = {
    name: 'Rajesh Kumar',
    email: 'rajesh@example.com',
    role: 'Village Representative',
    location: 'Rampur Village, Uttar Pradesh',
    joinedAt: 'December 2023',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'
  };

  const stats = [
    { label: 'Issues Reported', value: '5', icon: MessageCircle },
    { label: 'Issues Resolved', value: '3', icon: Award },
    { label: 'Community Impact', value: '150+', icon: Heart },
    { label: 'Upvotes Received', value: '42', icon: Heart }
  ];

  const recentActivity = [
    {
      id: 1,
      type: 'reported',
      title: 'Water Supply Disruption in Central Area',
      date: '2 days ago',
      status: 'in-progress'
    },
    {
      id: 2,
      type: 'upvoted',
      title: 'Damaged Road Blocking Emergency Access',
      date: '5 days ago',
      status: 'resolved'
    },
    {
      id: 3,
      type: 'commented',
      title: 'Frequent Power Outages Affecting Studies',
      date: '1 week ago',
      status: 'resolved'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'reported': return 'text-orange-600';
      case 'in-progress': return 'text-blue-600';
      case 'resolved': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'reported': return '📢';
      case 'upvoted': return '👍';
      case 'commented': return '💬';
      default: return '📝';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <div className="bg-white rounded-xl shadow-md p-8 mb-8">
        <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
          <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-green-200">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{user.name}</h1>
            <p className="text-lg text-green-600 font-medium mb-2">{user.role}</p>
            
            <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-4 text-gray-600">
              <div className="flex items-center space-x-1">
                <MapPin className="w-4 h-4" />
                <span>{user.location}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span>Joined {user.joinedAt}</span>
              </div>
            </div>
          </div>
          
          <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
            Edit Profile
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-md p-4 text-center">
              <Icon className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          );
        })}
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="md:col-span-2">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Recent Activity</h2>
            
            <div className="space-y-4">
              {recentActivity.map(activity => (
                <div key={activity.id} className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                  <div className="text-2xl">{getActivityIcon(activity.type)}</div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-600 mb-1">
                      You {activity.type} an issue
                    </p>
                    <h3 className="font-medium text-gray-900 mb-1">{activity.title}</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{activity.date}</span>
                      <span className={`text-xs font-medium ${getStatusColor(activity.status)}`}>
                        {activity.status.replace('-', ' ').toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Profile Info */}
        <div className="space-y-6">
          {/* Contact Info */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-700">Email</label>
                <p className="text-gray-900">{user.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Role</label>
                <p className="text-gray-900">{user.role}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Location</label>
                <p className="text-gray-900">{user.location}</p>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Achievements</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <Award className="w-4 h-4 text-yellow-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Community Leader</p>
                  <p className="text-sm text-gray-600">Reported 5+ issues</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Heart className="w-4 h-4 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Change Maker</p>
                  <p className="text-sm text-gray-600">Helped resolve 3 issues</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};