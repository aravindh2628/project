import React from 'react';
import { mockStories } from '../data/mockData';
import { Calendar, MapPin, TrendingUp } from 'lucide-react';

export const Stories: React.FC = () => {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'water': return 'bg-blue-100 text-blue-800';
      case 'electricity': return 'bg-yellow-100 text-yellow-800';
      case 'roads': return 'bg-gray-100 text-gray-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Success Stories</h1>
        <p className="text-gray-600">
          Real transformations from villages across India that inspire and guide other communities
        </p>
      </div>

      {/* Featured Story */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-2xl p-8 mb-12">
        <div className="max-w-4xl">
          <span className="inline-block px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm font-medium mb-4">
            Featured Success Story
          </span>
          <h2 className="text-3xl font-bold mb-4">
            How Solar Power Transformed Education in Rural Odisha
          </h2>
          <p className="text-xl text-green-100 mb-6">
            A community-led initiative brought solar power to 15 villages, enabling evening classes and increasing literacy rates by 40% in just one year.
          </p>
          <div className="flex items-center space-x-6 text-green-100">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5" />
              <span>Suryapur, Odisha</span>
            </div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5" />
              <span>40% increase in literacy</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stories Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {mockStories.map(story => (
          <div key={story.id} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden">
            {/* Before/After Images */}
            <div className="relative">
              <div className="grid grid-cols-2">
                <div className="relative">
                  <img
                    src={story.beforeImage}
                    alt="Before"
                    className="w-full h-32 object-cover"
                  />
                  <div className="absolute bottom-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-medium">
                    Before
                  </div>
                </div>
                <div className="relative">
                  <img
                    src={story.afterImage}
                    alt="After"
                    className="w-full h-32 object-cover"
                  />
                  <div className="absolute bottom-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-medium">
                    After
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6">
              {/* Category & Location */}
              <div className="flex items-center justify-between mb-3">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(story.category)}`}>
                  {story.category.charAt(0).toUpperCase() + story.category.slice(1)}
                </span>
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="w-4 h-4 mr-1" />
                  <span>{story.state}</span>
                </div>
              </div>

              {/* Title & Description */}
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{story.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{story.description}</p>

              {/* Impact */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <div className="flex items-start space-x-2">
                  <TrendingUp className="w-4 h-4 text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-800">Impact Achieved</p>
                    <p className="text-sm text-green-700">{story.impact}</p>
                  </div>
                </div>
              </div>

              {/* Date */}
              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="w-4 h-4 mr-1" />
                <span>Completed on {formatDate(story.date)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Call to Action */}
      <div className="mt-16 bg-orange-50 border border-orange-200 rounded-2xl p-8 text-center">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Share Your Village's Success Story</h3>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Has your community overcome an infrastructure challenge? Share your story to inspire other villages and showcase the power of collective action.
        </p>
        <button className="bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-orange-700 transition-colors">
          Submit Your Story
        </button>
      </div>
    </div>
  );
};