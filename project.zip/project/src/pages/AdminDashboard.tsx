import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useIssues } from '../context/IssuesContext';
import { useVolunteers } from '../context/VolunteerContext';
import { IssueCard } from '../components/IssueCard';
import { GoogleMapComponent } from '../components/GoogleMap';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';
import { 
  Users, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  Filter,
  Search,
  UserPlus,
  Settings
} from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

export const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const { issues, updateIssue } = useIssues();
  const { volunteers, assignIssueToVolunteer } = useVolunteers();
  
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'overview' | 'issues' | 'volunteers' | 'analytics'>('overview');

  const filteredIssues = issues.filter(issue => {
    const matchesCategory = selectedCategory === 'all' || issue.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || issue.status === selectedStatus;
    const matchesSearch = issue.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         issue.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         issue.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesStatus && matchesSearch;
  });

  const handleAssignVolunteer = (issueId: string, volunteerId: string) => {
    const volunteer = volunteers.find(v => v.id === volunteerId);
    if (volunteer) {
      updateIssue(issueId, {
        assignedVolunteerId: volunteerId,
        assignedTo: volunteer.name,
        status: 'in-progress'
      });
      assignIssueToVolunteer(volunteerId, issueId);
    }
  };

  // Statistics
  const stats = [
    {
      label: 'Total Issues',
      value: issues.length,
      icon: AlertTriangle,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      label: 'Active Volunteers',
      value: volunteers.filter(v => v.availability === 'available').length,
      icon: Users,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: 'Resolved Issues',
      value: issues.filter(i => i.status === 'resolved').length,
      icon: CheckCircle,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      label: 'In Progress',
      value: issues.filter(i => i.status === 'in-progress').length,
      icon: Clock,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    }
  ];

  // Chart data
  const statusChartData = {
    labels: ['Open', 'Reported', 'In Progress', 'Resolved', 'Verified'],
    datasets: [{
      data: [
        issues.filter(i => i.status === 'open').length,
        issues.filter(i => i.status === 'reported').length,
        issues.filter(i => i.status === 'in-progress').length,
        issues.filter(i => i.status === 'resolved').length,
        issues.filter(i => i.status === 'verified').length,
      ],
      backgroundColor: [
        '#ef4444',
        '#f97316',
        '#3b82f6',
        '#10b981',
        '#059669'
      ],
      borderWidth: 2,
      borderColor: '#ffffff'
    }]
  };

  const categoryChartData = {
    labels: ['Water', 'Electricity', 'Roads', 'Health', 'Education', 'Other'],
    datasets: [{
      label: 'Issues by Category',
      data: [
        issues.filter(i => i.category === 'water').length,
        issues.filter(i => i.category === 'electricity').length,
        issues.filter(i => i.category === 'roads').length,
        issues.filter(i => i.category === 'health').length,
        issues.filter(i => i.category === 'education').length,
        issues.filter(i => i.category === 'other').length,
      ],
      backgroundColor: [
        '#3b82f6',
        '#f59e0b',
        '#6b7280',
        '#ef4444',
        '#8b5cf6',
        '#10b981'
      ],
      borderRadius: 4
    }]
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
        <p className="text-gray-600">Manage issues, volunteers, and system overview</p>
      </div>

      {/* Navigation */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-wrap gap-2">
          {[
            { key: 'overview', label: 'Overview', icon: TrendingUp },
            { key: 'issues', label: 'Issues', icon: AlertTriangle },
            { key: 'volunteers', label: 'Volunteers', icon: Users },
            { key: 'analytics', label: 'Analytics', icon: TrendingUp }
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setViewMode(key as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                viewMode === key
                  ? 'bg-green-100 text-green-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-md p-4">
              <div className={`w-10 h-10 ${stat.bgColor} rounded-lg flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* Content based on view mode */}
      {viewMode === 'overview' && (
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Issues */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Issues</h2>
            <div className="space-y-4">
              {issues.slice(0, 5).map(issue => (
                <div key={issue.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{issue.title}</h3>
                    <p className="text-sm text-gray-600">{issue.location}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    issue.status === 'open' ? 'bg-red-100 text-red-800' :
                    issue.status === 'reported' ? 'bg-orange-100 text-orange-800' :
                    issue.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {issue.status.replace('-', ' ').toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Active Volunteers */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Active Volunteers</h2>
            <div className="space-y-4">
              {volunteers.filter(v => v.availability === 'available').slice(0, 5).map(volunteer => (
                <div key={volunteer.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{volunteer.name}</h3>
                    <p className="text-sm text-gray-600">{volunteer.location}</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {volunteer.specializations.slice(0, 2).map(spec => (
                        <span key={spec} className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">★ {volunteer.rating}</div>
                    <div className="text-xs text-gray-600">{volunteer.completedIssues} completed</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {viewMode === 'analytics' && (
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Status Distribution */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Issues by Status</h2>
            <div className="h-64">
              <Doughnut 
                data={statusChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'bottom'
                    }
                  }
                }}
              />
            </div>
          </div>

          {/* Category Distribution */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Issues by Category</h2>
            <div className="h-64">
              <Bar 
                data={categoryChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        stepSize: 1
                      }
                    }
                  }
                }}
              />
            </div>
          </div>
        </div>
      )}

      {viewMode === 'issues' && (
        <div>
          {/* Filters */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search issues..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="all">All Categories</option>
                <option value="water">Water</option>
                <option value="electricity">Electricity</option>
                <option value="roads">Roads</option>
                <option value="health">Health</option>
                <option value="education">Education</option>
                <option value="other">Other</option>
              </select>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="all">All Statuses</option>
                <option value="open">Open</option>
                <option value="reported">Reported</option>
                <option value="in-progress">In Progress</option>
                <option value="resolved">Resolved</option>
                <option value="verified">Verified</option>
              </select>
            </div>
          </div>

          {/* Issues Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredIssues.map(issue => (
              <div key={issue.id} className="relative">
                <IssueCard issue={issue} />
                {!issue.assignedVolunteerId && (
                  <div className="mt-3">
                    <select
                      onChange={(e) => e.target.value && handleAssignVolunteer(issue.id, e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      defaultValue=""
                    >
                      <option value="">Assign to volunteer...</option>
                      {volunteers
                        .filter(v => v.availability === 'available' && v.specializations.includes(issue.category))
                        .map(volunteer => (
                          <option key={volunteer.id} value={volunteer.id}>
                            {volunteer.name} (★ {volunteer.rating})
                          </option>
                        ))}
                    </select>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {viewMode === 'volunteers' && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Volunteer Management</h2>
            <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
              <UserPlus className="w-4 h-4" />
              <span>Add Volunteer</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Volunteer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Specializations
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rating
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Completed
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {volunteers.map(volunteer => (
                  <tr key={volunteer.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{volunteer.name}</div>
                        <div className="text-sm text-gray-500">{volunteer.email}</div>
                        <div className="text-sm text-gray-500">{volunteer.location}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1">
                        {volunteer.specializations.map(spec => (
                          <span key={spec} className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        volunteer.availability === 'available' ? 'bg-green-100 text-green-800' :
                        volunteer.availability === 'busy' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {volunteer.availability}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ★ {volunteer.rating}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {volunteer.completedIssues}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button className="text-green-600 hover:text-green-900 mr-3">
                        Edit
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};