import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useIssues } from '../context/IssuesContext';
import { useVolunteers } from '../context/VolunteerContext';
import { IssueCard } from '../components/IssueCard';
import { GoogleMapComponent } from '../components/GoogleMap';
import { 
  Users, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  MapPin, 
  Filter,
  TrendingUp,
  Award
} from 'lucide-react';

export const VolunteerDashboard: React.FC = () => {
  const { user } = useAuth();
  const { issues, updateIssue } = useIssues();
  const { volunteers, getVolunteerById } = useVolunteers();
  
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  const volunteer = user ? getVolunteerById(user.id) : null;
  
  // Get issues assigned to this volunteer or in their specialization areas
  const relevantIssues = issues.filter(issue => {
    if (issue.assignedVolunteerId === user?.id) return true;
    if (volunteer?.specializations.includes(issue.category)) return true;
    return false;
  });

  const assignedIssues = issues.filter(issue => issue.assignedVolunteerId === user?.id);
  const availableIssues = issues.filter(issue => 
    !issue.assignedVolunteerId && 
    volunteer?.specializations.includes(issue.category) &&
    issue.status === 'reported'
  );

  const filteredIssues = relevantIssues.filter(issue =>
    selectedCategory === 'all' || issue.category === selectedCategory
  );

  const handleTakeIssue = (issueId: string) => {
    updateIssue(issueId, {
      assignedVolunteerId: user?.id,
      assignedTo: user?.name,
      status: 'in-progress'
    });
  };

  const handleUpdateStatus = (issueId: string, status: 'in-progress' | 'resolved') => {
    updateIssue(issueId, { status });
  };

  const stats = [
    {
      label: 'Assigned Issues',
      value: assignedIssues.length,
      icon: Clock,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      label: 'Completed',
      value: volunteer?.completedIssues || 0,
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: 'Available Issues',
      value: availableIssues.length,
      icon: AlertTriangle,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      label: 'Rating',
      value: volunteer?.rating?.toFixed(1) || '5.0',
      icon: Award,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    }
  ];

  if (!volunteer) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Volunteer Profile Not Found
          </h2>
          <p className="text-gray-600">
            Please contact support to set up your volunteer profile.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Welcome back, {volunteer.name}!
        </h1>
        <p className="text-gray-600">
          Manage your assigned issues and help your community
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow-md p-4">
              <div className={`w-10 h-10 ${stat.bgColor} rounded-lg flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* Specializations */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-3">Your Specializations</h2>
        <div className="flex flex-wrap gap-2">
          {volunteer.specializations.map(spec => (
            <span
              key={spec}
              className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium capitalize"
            >
              {spec}
            </span>
          ))}
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="all">All Categories</option>
                {volunteer.specializations.map(spec => (
                  <option key={spec} value={spec}>
                    {spec.charAt(0).toUpperCase() + spec.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-2 rounded-lg text-sm font-medium ${
                viewMode === 'list'
                  ? 'bg-green-100 text-green-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              List View
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`px-3 py-2 rounded-lg text-sm font-medium ${
                viewMode === 'map'
                  ? 'bg-green-100 text-green-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Map View
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      {viewMode === 'map' ? (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Issues Map</h2>
          <GoogleMapComponent
            issues={filteredIssues}
            height="500px"
            zoom={8}
          />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Available Issues */}
          {availableIssues.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Available Issues in Your Area ({availableIssues.length})
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {availableIssues
                  .filter(issue => selectedCategory === 'all' || issue.category === selectedCategory)
                  .map(issue => (
                    <div key={issue.id} className="relative">
                      <IssueCard issue={issue} />
                      <div className="mt-3">
                        <button
                          onClick={() => handleTakeIssue(issue.id)}
                          className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium"
                        >
                          Take This Issue
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Assigned Issues */}
          {assignedIssues.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                Your Assigned Issues ({assignedIssues.length})
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {assignedIssues
                  .filter(issue => selectedCategory === 'all' || issue.category === selectedCategory)
                  .map(issue => (
                    <div key={issue.id} className="relative">
                      <IssueCard issue={issue} />
                      <div className="mt-3 space-y-2">
                        {issue.status === 'in-progress' && (
                          <button
                            onClick={() => handleUpdateStatus(issue.id, 'resolved')}
                            className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium"
                          >
                            Mark as Resolved
                          </button>
                        )}
                        {issue.status === 'reported' && (
                          <button
                            onClick={() => handleUpdateStatus(issue.id, 'in-progress')}
                            className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                          >
                            Start Working
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* No Issues */}
          {filteredIssues.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No issues found</h3>
              <p className="text-gray-600">
                {selectedCategory === 'all' 
                  ? 'No issues available in your specialization areas'
                  : `No ${selectedCategory} issues available`
                }
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};