import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, MapPin, AlertCircle, Upload } from 'lucide-react';
import { useIssues } from '../context/IssuesContext';
import { useAuth } from '../context/AuthContext';
import { GoogleMapComponent } from '../components/GoogleMap';
import { FileUpload } from '../components/FileUpload';

export const ReportIssue: React.FC = () => {
  const navigate = useNavigate();
  const { addIssue } = useIssues();
  const { user } = useAuth();
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    priority: '',
    location: '',
    coordinates: null as { lat: number; lng: number } | null,
    photos: [] as string[]
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const categories = [
    { value: 'water', label: 'Water Supply', icon: '💧' },
    { value: 'electricity', label: 'Electricity', icon: '⚡' },
    { value: 'roads', label: 'Roads & Transportation', icon: '🛣️' },
    { value: 'health', label: 'Healthcare', icon: '🏥' },
    { value: 'education', label: 'Education', icon: '🎓' },
    { value: 'environment', label: 'Environment', icon: '🌱' },
    { value: 'infrastructure', label: 'Infrastructure', icon: '🏗️' },
    { value: 'safety', label: 'Safety', icon: '🛡️' },
    { value: 'other', label: 'Other', icon: '📋' }
  ];

  const priorities = [
    { value: 'low', label: 'Low Priority', color: 'text-green-600' },
    { value: 'medium', label: 'Medium Priority', color: 'text-yellow-600' },
    { value: 'high', label: 'High Priority', color: 'text-orange-600' },
    { value: 'urgent', label: 'Urgent', color: 'text-red-600' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLocationSelect = (location: { lat: number; lng: number; address?: string }) => {
    setFormData(prev => ({
      ...prev,
      coordinates: { lat: location.lat, lng: location.lng },
      location: location.address || `${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}`
    }));
  };

  const handlePhotosChange = (photos: string[]) => {
    setFormData(prev => ({
      ...prev,
      photos
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Add the issue to the global state
    addIssue({
      title: formData.title,
      description: formData.description,
      category: formData.category as any,
      status: 'reported',
      priority: formData.priority as any,
      location: formData.location,
      coordinates: formData.coordinates || undefined,
      photos: formData.photos,
      reportedBy: user?.name || 'Anonymous User'
    });

    setIsSubmitting(false);
    setShowSuccess(true);
    
    // Reset form
    setFormData({
      title: '',
      description: '',
      category: '',
      priority: '',
      location: '',
      coordinates: null,
      photos: []
    });

    // Navigate to dashboard after showing success message
    setTimeout(() => {
      setShowSuccess(false);
      navigate('/dashboard');
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Report an Issue</h1>
        <p className="text-gray-600">
          Help improve your community by reporting infrastructure problems that need attention
        </p>
      </div>

      {/* Success Message */}
      {showSuccess && (
        <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-green-600 mr-2" />
            <span className="text-green-700 font-medium">
              Issue reported successfully! Redirecting to dashboard...
            </span>
          </div>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Issue Details</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* Title */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Issue Title *
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
                placeholder="Brief description of the problem"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category *
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">Select category</option>
                {categories.map(cat => (
                  <option key={cat.value} value={cat.value}>
                    {cat.icon} {cat.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Priority */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority Level *
              </label>
              <select
                name="priority"
                value={formData.priority}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">Select priority</option>
                {priorities.map(priority => (
                  <option key={priority.value} value={priority.value}>
                    {priority.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Description */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Detailed Description *
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                required
                rows={4}
                placeholder="Provide detailed information about the issue, including how it affects the community, when it started, and any relevant background information."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Location Selection */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Location</h2>
          <p className="text-gray-600 mb-4">
            Click on the map to select the exact location of the issue
          </p>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Selected Location
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleInputChange}
                required
                placeholder="Click on the map or enter location manually"
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
          </div>

          <GoogleMapComponent
            onLocationSelect={handleLocationSelect}
            selectedLocation={formData.coordinates}
            clickable={true}
            height="400px"
            center={formData.coordinates || undefined}
            zoom={formData.coordinates ? 15 : 6}
          />
        </div>

        {/* Photo Upload */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Add Photos</h2>
          <p className="text-gray-600 mb-4">
            Photos help authorities and volunteers better understand the issue
          </p>

          <FileUpload
            onFilesSelected={handlePhotosChange}
            currentFiles={formData.photos}
            maxFiles={5}
            maxSize={5}
            label="Upload Issue Photos"
          />
        </div>

        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting || !formData.coordinates}
            className="px-8 py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                <span>Submitting...</span>
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                <span>Submit Report</span>
              </>
            )}
          </button>
        </div>

        {!formData.coordinates && (
          <p className="text-sm text-red-600 text-center">
            Please select a location on the map before submitting
          </p>
        )}
      </form>
    </div>
  );
};