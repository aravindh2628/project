import React, { useState } from 'react';
import { mockResources } from '../data/mockData';
import { BookOpen, Clock, DollarSign, Wrench, ChevronRight } from 'lucide-react';

export const Resources: React.FC = () => {
  const [selectedResource, setSelectedResource] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'water', 'electricity', 'roads', 'health', 'education'];

  const filteredResources = mockResources.filter(resource =>
    selectedCategory === 'all' || resource.category === selectedCategory
  );

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCostColor = (cost: string) => {
    switch (cost) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Educational Resources</h1>
        <p className="text-gray-600">
          Learn practical solutions for common infrastructure problems in rural areas
        </p>
      </div>

      {/* Category Filter */}
      <div className="mb-8">
        <div className="flex flex-wrap gap-2">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-green-50 border border-gray-300'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map(resource => (
          <div key={resource.id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="p-6">
              {/* Resource Image */}
              <div className="mb-4">
                <img
                  src={resource.images[0]}
                  alt={resource.title}
                  className="w-full h-48 object-cover rounded-lg"
                />
              </div>

              {/* Resource Info */}
              <div className="mb-4">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{resource.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{resource.description}</p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(resource.difficulty)}`}>
                    {resource.difficulty.charAt(0).toUpperCase() + resource.difficulty.slice(1)}
                  </span>
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
                  </span>
                </div>

                {/* Resource Details */}
                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-gray-600">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>{resource.timeRequired}</span>
                  </div>
                  <div className="flex items-center">
                    <DollarSign className={`w-4 h-4 mr-2 ${getCostColor(resource.cost)}`} />
                    <span className={getCostColor(resource.cost)}>
                      {resource.cost.charAt(0).toUpperCase() + resource.cost.slice(1)} Cost
                    </span>
                  </div>
                </div>
              </div>

              {/* View Details Button */}
              <button
                onClick={() => setSelectedResource(resource.id)}
                className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>View Instructions</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Resource Detail Modal */}
      {selectedResource && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {(() => {
                const resource = mockResources.find(r => r.id === selectedResource);
                if (!resource) return null;

                return (
                  <>
                    <div className="flex justify-between items-start mb-6">
                      <h2 className="text-2xl font-bold text-gray-900">{resource.title}</h2>
                      <button
                        onClick={() => setSelectedResource(null)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <img
                          src={resource.images[0]}
                          alt={resource.title}
                          className="w-full h-64 object-cover rounded-lg"
                        />
                      </div>
                      <div>
                        <p className="text-gray-600 mb-4">{resource.content}</p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center">
                            <Wrench className="w-4 h-4 mr-2 text-gray-600" />
                            <span className={`font-medium ${getDifficultyColor(resource.difficulty).replace('bg-', 'text-').replace('-100', '-800')}`}>
                              {resource.difficulty.charAt(0).toUpperCase() + resource.difficulty.slice(1)} Difficulty
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-2 text-gray-600" />
                            <span>{resource.timeRequired}</span>
                          </div>
                          <div className="flex items-center">
                            <DollarSign className={`w-4 h-4 mr-2 ${getCostColor(resource.cost)}`} />
                            <span className={getCostColor(resource.cost)}>
                              {resource.cost.charAt(0).toUpperCase() + resource.cost.slice(1)} Cost
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Materials Needed</h3>
                        <ul className="space-y-2">
                          {resource.materials.map((material, index) => (
                            <li key={index} className="flex items-center text-gray-700">
                              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                              {material}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Step-by-Step Instructions</h3>
                        <ol className="space-y-3">
                          {resource.steps.map((step, index) => (
                            <li key={index} className="flex items-start">
                              <div className="w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-medium mr-3 mt-0.5">
                                {index + 1}
                              </div>
                              <span className="text-gray-700">{step}</span>
                            </li>
                          ))}
                        </ol>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};