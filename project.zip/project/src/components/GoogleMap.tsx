import React, { useState, useCallback } from 'react';
import { GoogleMap, LoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import { Issue } from '../types';

interface GoogleMapComponentProps {
  issues?: Issue[];
  onLocationSelect?: (location: { lat: number; lng: number; address?: string }) => void;
  selectedLocation?: { lat: number; lng: number };
  height?: string;
  center?: { lat: number; lng: number };
  zoom?: number;
  clickable?: boolean;
}

const mapContainerStyle = {
  width: '100%',
  height: '400px'
};

const defaultCenter = {
  lat: 20.5937, // Center of India
  lng: 78.9629
};

const libraries: ("places" | "geometry" | "drawing" | "visualization")[] = ["places"];

export const GoogleMapComponent: React.FC<GoogleMapComponentProps> = ({
  issues = [],
  onLocationSelect,
  selectedLocation,
  height = '400px',
  center = defaultCenter,
  zoom = 6,
  clickable = false
}) => {
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);

  const mapOptions = {
    disableDefaultUI: false,
    zoomControl: true,
    streetViewControl: false,
    mapTypeControl: false,
    fullscreenControl: true,
  };

  const onMapClick = useCallback((event: google.maps.MapMouseEvent) => {
    if (clickable && onLocationSelect && event.latLng) {
      const lat = event.latLng.lat();
      const lng = event.latLng.lng();
      
      // Reverse geocoding to get address
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === 'OK' && results?.[0]) {
          onLocationSelect({
            lat,
            lng,
            address: results[0].formatted_address
          });
        } else {
          onLocationSelect({ lat, lng });
        }
      });
    }
  }, [clickable, onLocationSelect]);

  const getMarkerIcon = (issue: Issue) => {
    const colors = {
      'open': '#ef4444', // red
      'reported': '#f97316', // orange
      'in-progress': '#3b82f6', // blue
      'resolved': '#10b981', // green
      'verified': '#059669' // dark green
    };

    return {
      path: google.maps.SymbolPath.CIRCLE,
      fillColor: colors[issue.status] || '#6b7280',
      fillOpacity: 0.8,
      strokeColor: '#ffffff',
      strokeWeight: 2,
      scale: 8
    };
  };

  const customMapContainerStyle = {
    ...mapContainerStyle,
    height
  };

  return (
    <LoadScript
      googleMapsApiKey="AIzaSyDWeYaXijoWdc7SrfWuMfQk9tyw5W7NdB3c"
      libraries={libraries}
    >
      <GoogleMap
        mapContainerStyle={customMapContainerStyle}
        center={center}
        zoom={zoom}
        options={mapOptions}
        onClick={onMapClick}
      >
        {/* Issue markers */}
        {issues.map((issue) => (
          issue.coordinates && (
            <Marker
              key={issue.id}
              position={issue.coordinates}
              icon={getMarkerIcon(issue)}
              onClick={() => setSelectedIssue(issue)}
            />
          )
        ))}

        {/* Selected location marker (for issue reporting) */}
        {selectedLocation && (
          <Marker
            position={selectedLocation}
            icon={{
              path: google.maps.SymbolPath.CIRCLE,
              fillColor: '#10b981',
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 3,
              scale: 10
            }}
          />
        )}

        {/* Info window for selected issue */}
        {selectedIssue && selectedIssue.coordinates && (
          <InfoWindow
            position={selectedIssue.coordinates}
            onCloseClick={() => setSelectedIssue(null)}
          >
            <div className="p-2 max-w-xs">
              <h3 className="font-semibold text-gray-900 mb-1">
                {selectedIssue.title}
              </h3>
              <p className="text-sm text-gray-600 mb-2">
                {selectedIssue.description.substring(0, 100)}...
              </p>
              <div className="flex items-center justify-between text-xs">
                <span className={`px-2 py-1 rounded-full font-medium ${
                  selectedIssue.status === 'open' ? 'bg-red-100 text-red-800' :
                  selectedIssue.status === 'reported' ? 'bg-orange-100 text-orange-800' :
                  selectedIssue.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                  selectedIssue.status === 'resolved' ? 'bg-green-100 text-green-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {selectedIssue.status.replace('-', ' ').toUpperCase()}
                </span>
                <span className="text-gray-500">
                  {selectedIssue.category.charAt(0).toUpperCase() + selectedIssue.category.slice(1)}
                </span>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </LoadScript>
  );
};