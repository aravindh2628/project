import React from 'react';
import { Issue } from '../types';
import { MapPin, Clock, ThumbsUp, MessageCircle, AlertTriangle, CheckCircle, Timer } from 'lucide-react';

interface IssueCardProps {
  issue: Issue;
  onClick?: () => void;
}

export const IssueCard: React.FC<IssueCardProps> = ({ issue, onClick }) => {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'water': return 'bg-blue-100 text-blue-800';
      case 'electricity': return 'bg-yellow-100 text-yellow-800';
      case 'roads': return 'bg-gray-100 text-gray-800';
      case 'health': return 'bg-red-100 text-red-800';
      case 'education': return 'bg-purple-100 text-purple-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'reported': return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      case 'in-progress': return <Timer className="w-4 h-4 text-blue-500" />;
      case 'resolved': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'verified': return <CheckCircle className="w-4 h-4 text-green-600" />;
      default: return <AlertTriangle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'border-l-red-500';
      case 'high': return 'border-l-orange-500';
      case 'medium': return 'border-l-yellow-500';
      case 'low': return 'border-l-green-500';
      default: return 'border-l-gray-500';
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(
      Math.ceil((date.getTime() - Date.now()) / (1000 * 60 * 60 * 24)),
      'day'
    );
  };

  return (
    <div
      className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer border-l-4 ${getPriorityColor(issue.priority)}`}
      onClick={onClick}
    >
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(issue.category)}`}>
              {issue.category.charAt(0).toUpperCase() + issue.category.slice(1)}
            </span>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
              issue.priority === 'urgent' ? 'bg-red-100 text-red-800' :
              issue.priority === 'high' ? 'bg-orange-100 text-orange-800' :
              issue.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
              'bg-green-100 text-green-800'
            }`}>
              {issue.priority.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center space-x-1">
            {getStatusIcon(issue.status)}
            <span className="text-sm text-gray-600 capitalize">{issue.status.replace('-', ' ')}</span>
          </div>
        </div>

        <h3 className="text-lg font-semibold text-gray-900 mb-2">{issue.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{issue.description}</p>

        <div className="flex items-center text-sm text-gray-500 mb-4">
          <MapPin className="w-4 h-4 mr-1" />
          <span>{issue.location}</span>
        </div>

        {issue.photos && issue.photos.length > 0 && (
          <div className="mb-4">
            <img
              src={issue.photos[0]}
              alt="Issue"
              className="w-full h-32 object-cover rounded-md"
            />
          </div>
        )}

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <ThumbsUp className="w-4 h-4" />
              <span>{issue.upvotes}</span>
            </div>
            <div className="flex items-center space-x-1">
              <MessageCircle className="w-4 h-4" />
              <span>{issue.comments.length}</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>Reported {formatDate(issue.reportedAt)}</span>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-gray-100">
          <p className="text-xs text-gray-500">
            Reported by <span className="font-medium">{issue.reportedBy}</span>
            {issue.assignedTo && (
              <span> • Assigned to <span className="font-medium">{issue.assignedTo}</span></span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
};