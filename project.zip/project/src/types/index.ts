export interface Issue {
  id: string;
  title: string;
  description: string;
  category: 'water' | 'electricity' | 'roads' | 'health' | 'education' | 'environment' | 'infrastructure' | 'safety' | 'other';
  status: 'open' | 'reported' | 'in-progress' | 'resolved' | 'verified';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  location: string;
  coordinates?: { lat: number; lng: number };
  photos: string[];
  reportedBy: string;
  reportedAt: Date;
  assignedTo?: string;
  assignedVolunteerId?: string;
  updatedAt: Date;
  upvotes: number;
  comments: Comment[];
}

export interface Comment {
  id: string;
  content: string;
  author: string;
  role: UserRole;
  createdAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  location: string;
  avatar?: string;
  joinedAt: Date;
  isVerified?: boolean;
}

export interface Volunteer extends User {
  phone?: string;
  address?: string;
  profileImage?: string;
  specializations: string[];
  availability: 'available' | 'busy' | 'unavailable';
  assignedIssues: string[];
  completedIssues: number;
  rating: number;
}

export type UserRole = 'citizen' | 'volunteer' | 'admin';

export interface Resource {
  id: string;
  title: string;
  description: string;
  category: string;
  content: string;
  images: string[];
  difficulty: 'easy' | 'medium' | 'hard';
  cost: 'low' | 'medium' | 'high';
  timeRequired: string;
  materials: string[];
  steps: string[];
}

export interface Story {
  id: string;
  title: string;
  village: string;
  state: string;
  description: string;
  beforeImage: string;
  afterImage: string;
  impact: string;
  date: Date;
  category: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
  role?: UserRole;
}

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  role: UserRole;
  phone?: string;
  address?: string;
  specializations?: string[];
}