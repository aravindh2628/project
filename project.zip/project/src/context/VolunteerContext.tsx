import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Volunteer } from '../types';

interface VolunteerContextType {
  volunteers: Volunteer[];
  addVolunteer: (volunteer: Omit<Volunteer, 'id' | 'joinedAt' | 'completedIssues' | 'rating'>) => void;
  updateVolunteer: (id: string, updates: Partial<Volunteer>) => void;
  getVolunteerById: (id: string) => Volunteer | undefined;
  assignIssueToVolunteer: (volunteerId: string, issueId: string) => void;
  getAvailableVolunteers: () => Volunteer[];
}

const VolunteerContext = createContext<VolunteerContextType | undefined>(undefined);

export const useVolunteers = () => {
  const context = useContext(VolunteerContext);
  if (!context) {
    throw new Error('useVolunteers must be used within a VolunteerProvider');
  }
  return context;
};

interface VolunteerProviderProps {
  children: ReactNode;
}

const mockVolunteers: Volunteer[] = [
  {
    id: '2',
    name: 'Rajesh Kumar',
    email: 'rajesh@example.com',
    role: 'volunteer',
    location: 'Rampur Village, UP',
    joinedAt: new Date('2023-12-01'),
    isVerified: true,
    phone: '+91-9876543210',
    address: 'Rampur Village, Uttar Pradesh',
    specializations: ['water', 'infrastructure'],
    availability: 'available',
    assignedIssues: ['1'],
    completedIssues: 5,
    rating: 4.8
  },
  {
    id: '4',
    name: 'Dr. Priya Mehta',
    email: 'priya@ruralngo.org',
    role: 'volunteer',
    location: 'Delhi',
    joinedAt: new Date('2023-11-15'),
    isVerified: true,
    phone: '+91-9876543211',
    address: 'New Delhi',
    specializations: ['health', 'education'],
    availability: 'available',
    assignedIssues: [],
    completedIssues: 12,
    rating: 4.9
  },
  {
    id: '5',
    name: 'Amit Singh',
    email: 'amit@example.com',
    role: 'volunteer',
    location: 'Jaipur, Rajasthan',
    joinedAt: new Date('2024-01-10'),
    isVerified: true,
    phone: '+91-9876543212',
    address: 'Jaipur, Rajasthan',
    specializations: ['electricity', 'roads'],
    availability: 'busy',
    assignedIssues: ['2', '3'],
    completedIssues: 8,
    rating: 4.6
  }
];

export const VolunteerProvider: React.FC<VolunteerProviderProps> = ({ children }) => {
  const [volunteers, setVolunteers] = useState<Volunteer[]>(mockVolunteers);

  const addVolunteer = (volunteerData: Omit<Volunteer, 'id' | 'joinedAt' | 'completedIssues' | 'rating'>) => {
    const newVolunteer: Volunteer = {
      ...volunteerData,
      id: Date.now().toString(),
      joinedAt: new Date(),
      completedIssues: 0,
      rating: 5.0,
      assignedIssues: []
    };

    setVolunteers(prev => [...prev, newVolunteer]);
  };

  const updateVolunteer = (id: string, updates: Partial<Volunteer>) => {
    setVolunteers(prev =>
      prev.map(volunteer =>
        volunteer.id === id ? { ...volunteer, ...updates } : volunteer
      )
    );
  };

  const getVolunteerById = (id: string) => {
    return volunteers.find(volunteer => volunteer.id === id);
  };

  const assignIssueToVolunteer = (volunteerId: string, issueId: string) => {
    setVolunteers(prev =>
      prev.map(volunteer =>
        volunteer.id === volunteerId
          ? {
              ...volunteer,
              assignedIssues: [...volunteer.assignedIssues, issueId],
              availability: volunteer.assignedIssues.length >= 2 ? 'busy' : volunteer.availability
            }
          : volunteer
      )
    );
  };

  const getAvailableVolunteers = () => {
    return volunteers.filter(volunteer => volunteer.availability === 'available');
  };

  return (
    <VolunteerContext.Provider value={{
      volunteers,
      addVolunteer,
      updateVolunteer,
      getVolunteerById,
      assignIssueToVolunteer,
      getAvailableVolunteers
    }}>
      {children}
    </VolunteerContext.Provider>
  );
};