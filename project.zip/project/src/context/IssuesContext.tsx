import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Issue } from '../types';
import { mockIssues } from '../data/mockData';

interface IssuesContextType {
  issues: Issue[];
  addIssue: (issue: Omit<Issue, 'id' | 'reportedAt' | 'updatedAt' | 'upvotes' | 'comments'>) => void;
  updateIssue: (id: string, updates: Partial<Issue>) => void;
  getIssueById: (id: string) => Issue | undefined;
}

const IssuesContext = createContext<IssuesContextType | undefined>(undefined);

export const useIssues = () => {
  const context = useContext(IssuesContext);
  if (!context) {
    throw new Error('useIssues must be used within an IssuesProvider');
  }
  return context;
};

interface IssuesProviderProps {
  children: ReactNode;
}

export const IssuesProvider: React.FC<IssuesProviderProps> = ({ children }) => {
  const [issues, setIssues] = useState<Issue[]>(mockIssues);

  const addIssue = (issueData: Omit<Issue, 'id' | 'reportedAt' | 'updatedAt' | 'upvotes' | 'comments'>) => {
    const newIssue: Issue = {
      ...issueData,
      id: Date.now().toString(), // Simple ID generation
      reportedAt: new Date(),
      updatedAt: new Date(),
      upvotes: 0,
      comments: []
    };

    setIssues(prevIssues => [newIssue, ...prevIssues]);
  };

  const updateIssue = (id: string, updates: Partial<Issue>) => {
    setIssues(prevIssues =>
      prevIssues.map(issue =>
        issue.id === id
          ? { ...issue, ...updates, updatedAt: new Date() }
          : issue
      )
    );
  };

  const getIssueById = (id: string) => {
    return issues.find(issue => issue.id === id);
  };

  return (
    <IssuesContext.Provider value={{ issues, addIssue, updateIssue, getIssueById }}>
      {children}
    </IssuesContext.Provider>
  );
};