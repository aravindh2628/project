import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, AuthState, LoginCredentials, RegisterData, UserRole } from '../types';

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// Mock users for demonstration
const mockUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@gramaconnect.com',
    role: 'admin',
    location: 'Delhi, India',
    joinedAt: new Date('2023-01-01'),
    isVerified: true
  },
  {
    id: '2',
    name: 'Rajesh Kumar',
    email: 'rajesh@example.com',
    role: 'volunteer',
    location: 'Rampur Village, UP',
    joinedAt: new Date('2023-12-01'),
    isVerified: true
  },
  {
    id: '3',
    name: 'Priya Sharma',
    email: 'priya@example.com',
    role: 'citizen',
    location: 'Devgarh, Rajasthan',
    joinedAt: new Date('2024-01-05'),
    isVerified: true
  }
];

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true
  });

  useEffect(() => {
    // Check for stored auth data on mount
    const storedUser = localStorage.getItem('gramaconnect_user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setAuthState({
          user,
          isAuthenticated: true,
          isLoading: false
        });
      } catch (error) {
        localStorage.removeItem('gramaconnect_user');
        setAuthState(prev => ({ ...prev, isLoading: false }));
      }
    } else {
      setAuthState(prev => ({ ...prev, isLoading: false }));
    }
  }, []);

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Find user by email
      const user = mockUsers.find(u => u.email === credentials.email);
      
      if (!user) {
        throw new Error('User not found');
      }

      // In a real app, you'd verify the password hash
      // For demo purposes, we'll accept any password
      
      // Check role if specified
      if (credentials.role && user.role !== credentials.role) {
        throw new Error('Invalid role for this user');
      }

      const authUser: User = {
        ...user,
        joinedAt: new Date(user.joinedAt)
      };

      setAuthState({
        user: authUser,
        isAuthenticated: true,
        isLoading: false
      });

      // Store in localStorage
      localStorage.setItem('gramaconnect_user', JSON.stringify(authUser));

      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Check if email already exists
      const existingUser = mockUsers.find(u => u.email === data.email);
      if (existingUser) {
        throw new Error('Email already exists');
      }

      // Create new user
      const newUser: User = {
        id: Date.now().toString(),
        name: data.name,
        email: data.email,
        role: data.role,
        location: data.address || 'Not specified',
        joinedAt: new Date(),
        isVerified: false
      };

      // Add to mock users (in real app, this would be saved to database)
      mockUsers.push(newUser);

      setAuthState({
        user: newUser,
        isAuthenticated: true,
        isLoading: false
      });

      // Store in localStorage
      localStorage.setItem('gramaconnect_user', JSON.stringify(newUser));

      return true;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const logout = () => {
    setAuthState({
      user: null,
      isAuthenticated: false,
      isLoading: false
    });
    localStorage.removeItem('gramaconnect_user');
  };

  const updateProfile = (updates: Partial<User>) => {
    if (authState.user) {
      const updatedUser = { ...authState.user, ...updates };
      setAuthState(prev => ({
        ...prev,
        user: updatedUser
      }));
      localStorage.setItem('gramaconnect_user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider value={{
      ...authState,
      login,
      register,
      logout,
      updateProfile
    }}>
      {children}
    </AuthContext.Provider>
  );
};