import { Issue, User, Resource, Story, Volunteer } from '../types';

export const mockIssues: Issue[] = [
  {
    id: '1',
    title: 'Water Supply Disruption in Central Area',
    description: 'The main water pipeline has been damaged, affecting over 200 households. Families are forced to walk 2km to fetch water from the nearest well.',
    category: 'water',
    status: 'reported',
    priority: 'urgent',
    location: 'Rampur Village, Uttar Pradesh',
    coordinates: { lat: 26.8467, lng: 80.9462 },
    photos: [
      'https://images.pexels.com/photos/4252134/pexels-photo-4252134.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/2280550/pexels-photo-2280550.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    reportedBy: 'Rajesh Kumar',
    reportedAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
    upvotes: 23,
    comments: [
      {
        id: '1',
        content: 'This is affecting my family too. We need immediate action.',
        author: 'Sunita Devi',
        role: 'citizen',
        createdAt: new Date('2024-01-16')
      }
    ]
  },
  {
    id: '2',
    title: 'Damaged Road Blocking Emergency Access',
    description: 'Heavy monsoon rains have created deep potholes on the main road. Ambulances and emergency vehicles cannot reach the village.',
    category: 'roads',
    status: 'in-progress',
    priority: 'high',
    location: 'Kishanganj, Bihar',
    coordinates: { lat: 26.1124, lng: 87.9482 },
    photos: [
      'https://images.pexels.com/photos/2132227/pexels-photo-2132227.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    reportedBy: 'Mohan Singh',
    reportedAt: new Date('2024-01-10'),
    assignedTo: 'Amit Singh',
    assignedVolunteerId: '5',
    updatedAt: new Date('2024-01-18'),
    upvotes: 45,
    comments: []
  },
  {
    id: '3',
    title: 'Frequent Power Outages Affecting Studies',
    description: 'Children cannot study in the evening due to power cuts lasting 8-10 hours daily. This is affecting their education.',
    category: 'electricity',
    status: 'resolved',
    priority: 'medium',
    location: 'Devgarh, Rajasthan',
    coordinates: { lat: 25.5788, lng: 73.9097 },
    photos: [
      'https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    reportedBy: 'Priya Sharma',
    reportedAt: new Date('2024-01-05'),
    assignedTo: 'Amit Singh',
    assignedVolunteerId: '5',
    updatedAt: new Date('2024-01-20'),
    upvotes: 18,
    comments: []
  }
];

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Rajesh Kumar',
    email: 'rajesh@example.com',
    role: 'citizen',
    location: 'Rampur Village, UP',
    joinedAt: new Date('2023-12-01')
  },
  {
    id: '2',
    name: 'Dr. Priya Mehta',
    email: 'priya@ruralngo.org',
    role: 'volunteer',
    location: 'Delhi',
    joinedAt: new Date('2023-11-15')
  }
];

export const mockResources: Resource[] = [
  {
    id: '1',
    title: 'DIY Water Purification System',
    description: 'Build a simple water filter using locally available materials to ensure safe drinking water.',
    category: 'water',
    content: 'Learn how to create an effective water purification system using sand, gravel, and charcoal.',
    images: [
      'https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    difficulty: 'easy',
    cost: 'low',
    timeRequired: '2 hours',
    materials: ['Plastic bottles', 'Sand', 'Gravel', 'Charcoal', 'Cotton cloth'],
    steps: [
      'Clean all materials thoroughly',
      'Layer materials in bottle: cotton, charcoal, sand, gravel',
      'Create small holes in bottle cap',
      'Pour water slowly and collect filtered water'
    ]
  },
  {
    id: '2',
    title: 'Solar Lighting Solutions',
    description: 'Create affordable solar lighting for homes and community spaces.',
    category: 'electricity',
    content: 'Step-by-step guide to building solar LED lights for rural areas.',
    images: [
      'https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    difficulty: 'medium',
    cost: 'medium',
    timeRequired: '4 hours',
    materials: ['Solar panel', 'LED bulbs', 'Battery', 'Wiring', 'Switch'],
    steps: [
      'Connect solar panel to battery',
      'Wire LED bulbs in parallel',
      'Install switch mechanism',
      'Test the complete system'
    ]
  }
];

export const mockStories: Story[] = [
  {
    id: '1',
    title: 'Clean Water Transforms Chandanpur',
    village: 'Chandanpur',
    state: 'Madhya Pradesh',
    description: 'Community-led water harvesting project brings clean water to 500 families.',
    beforeImage: 'https://images.pexels.com/photos/2280550/pexels-photo-2280550.jpeg?auto=compress&cs=tinysrgb&w=800',
    afterImage: 'https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=800',
    impact: 'Reduced water-borne diseases by 80%, increased school attendance by 60%',
    date: new Date('2024-01-01'),
    category: 'water'
  },
  {
    id: '2',
    title: 'Solar Power Illuminates Education',
    village: 'Suryapur',
    state: 'Odisha',
    description: 'Solar installation enables evening classes and improves literacy rates.',
    beforeImage: 'https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=800',
    afterImage: 'https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg?auto=compress&cs=tinysrgb&w=800',
    impact: 'Evening classes now available, 40% increase in literacy rate',
    date: new Date('2023-12-15'),
    category: 'electricity'
  }
];