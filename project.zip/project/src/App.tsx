import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { IssuesProvider } from './context/IssuesContext';
import { VolunteerProvider } from './context/VolunteerContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Dashboard } from './pages/Dashboard';
import { VolunteerDashboard } from './pages/VolunteerDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { ReportIssue } from './pages/ReportIssue';
import { Resources } from './pages/Resources';
import { Stories } from './pages/Stories';
import { Profile } from './pages/Profile';

function App() {
  return (
    <AuthProvider>
      <IssuesProvider>
        <VolunteerProvider>
          <Router>
            <Routes>
              {/* Public routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              
              {/* Protected routes with layout */}
              <Route path="/*" element={
                <ProtectedRoute>
                  <Layout>
                    <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/dashboard" element={<Dashboard />} />
                      <Route path="/volunteer-dashboard" element={
                        <ProtectedRoute requiredRole="volunteer">
                          <VolunteerDashboard />
                        </ProtectedRoute>
                      } />
                      <Route path="/admin-dashboard" element={
                        <ProtectedRoute requiredRole="admin">
                          <AdminDashboard />
                        </ProtectedRoute>
                      } />
                      <Route path="/report" element={<ReportIssue />} />
                      <Route path="/resources" element={<Resources />} />
                      <Route path="/stories" element={<Stories />} />
                      <Route path="/profile" element={<Profile />} />
                    </Routes>
                  </Layout>
                </ProtectedRoute>
              } />
            </Routes>
          </Router>
        </VolunteerProvider>
      </IssuesProvider>
    </AuthProvider>
  );
}

export default App;